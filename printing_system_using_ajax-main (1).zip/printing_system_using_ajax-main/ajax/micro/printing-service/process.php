<?php
/**
 * process.php — Backend for Online Printing Service
 * Handles:
 *   1. File upload + price calculation
 *   2. Order confirmation with pickup time
 */

header('Content-Type: application/json');

// ── Order Confirmation ────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'confirm') {
    echo json_encode([
        'status'     => 'confirmed',
        'serverTime' => date('c')   // ISO 8601 — used by JS to compute pickup time
    ]);
    exit;
}

// ── Price Calculation ─────────────────────────────────────────

// Validate file upload
if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['error' => 'File upload failed. Please try again.']);
    exit;
}

$file     = $_FILES['file'];
$fileName = $file['name'];
$fileExt  = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

// Validate file type
$allowed = ['pdf', 'doc', 'docx'];
if (!in_array($fileExt, $allowed)) {
    echo json_encode(['error' => 'Only PDF or DOC/DOCX files are allowed.']);
    exit;
}

// Validate copies
$copies = intval($_POST['copies'] ?? 1);
if ($copies < 1) {
    echo json_encode(['error' => 'Number of copies must be at least 1.']);
    exit;
}

// Validate print type
$printType = $_POST['printType'] ?? 'bw';
if (!in_array($printType, ['bw', 'color'])) {
    $printType = 'bw';
}

// ── Page Count ───────────────────────────────────────────────
// Attempt to count pages from PDF by reading xref/page markers.
// Falls back to a random count (5–20) for DOC files or unreadable PDFs.
$pages = estimatePageCount($file['tmp_name'], $fileExt);

// ── Price Calculation ────────────────────────────────────────
$pricePerPage = ($printType === 'color') ? 5 : 2;
$total        = $pages * $pricePerPage * $copies;
$printLabel   = ($printType === 'color') ? 'Color' : 'Black & White';

echo json_encode([
    'pages'        => $pages,
    'printType'    => $printLabel,
    'pricePerPage' => $pricePerPage,
    'copies'       => $copies,
    'total'        => $total
]);
exit;


// ── Helper: Estimate Page Count ──────────────────────────────
/**
 * For PDFs: scan binary content for "/Page" markers to approximate page count.
 * For DOC/DOCX or unreadable PDFs: return a random number between 5 and 20.
 *
 * @param string $tmpPath  Temp file path on server
 * @param string $ext      File extension (pdf|doc|docx)
 * @return int             Estimated page count
 */
function estimatePageCount(string $tmpPath, string $ext): int {
    if ($ext === 'pdf') {
        $content = @file_get_contents($tmpPath);
        if ($content !== false) {
            // Count occurrences of "/Type /Page" (standard PDF page marker)
            $count = substr_count($content, '/Type /Page');
            if ($count > 0) {
                return $count;
            }
            // Fallback: count "/Page " references
            $count = substr_count($content, '/Page ');
            if ($count > 0) {
                return max(1, intdiv($count, 2)); // rough estimate
            }
        }
    }
    // DOC/DOCX or unreadable PDF — simulate a random page count
    return rand(5, 20);
}
