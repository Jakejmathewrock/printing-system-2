$(document).ready(function () {

  // ── State ──────────────────────────────────────────────────
  let currentStep = 1;
  let priceData   = {};

  // ── Step Navigation ────────────────────────────────────────
  function goToStep(n) {
    // Update panels
    $('.step-panel').removeClass('active');
    $('#panel-' + n).addClass('active');

    // Update step indicators
    $('.step').each(function () {
      const s = parseInt($(this).data('step'));
      $(this).removeClass('active completed');
      if (s === n)  $(this).addClass('active');
      if (s < n)    $(this).addClass('completed');
    });

    // Update connector lines
    $('.step-line').each(function (i) {
      $(this).toggleClass('completed', i < n - 1);
    });

    currentStep = n;
    // Scroll card into view smoothly
    $('.card')[0].scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  // ── Drag & Drop Upload Zone ─────────────────────────────────
  const $zone = $('#uploadZone');

  $zone.on('dragover dragenter', function (e) {
    e.preventDefault();
    $zone.addClass('drag-over');
  });
  $zone.on('dragleave drop', function (e) {
    e.preventDefault();
    $zone.removeClass('drag-over');
    if (e.type === 'drop') {
      const dt = e.originalEvent.dataTransfer;
      if (dt && dt.files.length) {
        // Assign dropped file to the input
        const input = $('#fileInput')[0];
        // DataTransfer trick to set files on input
        try {
          const transfer = new DataTransfer();
          transfer.items.add(dt.files[0]);
          input.files = transfer.files;
        } catch (_) {}
        handleFileSelected(dt.files[0]);
      }
    }
  });

  $('#fileInput').on('change', function () {
    if (this.files[0]) handleFileSelected(this.files[0]);
  });

  function handleFileSelected(file) {
    const ext = file.name.split('.').pop().toLowerCase();
    if (!['pdf', 'doc', 'docx'].includes(ext)) {
      showFieldError('#fileError', 'Only PDF or DOC/DOCX files are allowed.');
      resetFileInput();
      return;
    }
    clearFieldError('#fileError');

    // Show preview
    $('#uploadIdle').addClass('hidden');
    $('#uploadPreview').removeClass('hidden');
    $('#fileName').text(file.name);
    $('#fileSize').text(formatBytes(file.size));
    $('#fileIconBadge')
      .text(ext.toUpperCase())
      .toggleClass('doc-icon', ext !== 'pdf');
  }

  $('#fileRemove').on('click', function (e) {
    e.stopPropagation();
    resetFileInput();
  });

  function resetFileInput() {
    $('#fileInput').val('');
    $('#uploadPreview').addClass('hidden');
    $('#uploadIdle').removeClass('hidden');
  }

  function formatBytes(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1048576).toFixed(1) + ' MB';
  }

  // ── Print Type Card Selection ───────────────────────────────
  $('.type-card').on('click', function () {
    $('.type-card').removeClass('active');
    $(this).addClass('active');
    $(this).find('input[type="radio"]').prop('checked', true);
  });

  // ── Copies +/- Buttons ──────────────────────────────────────
  $('#copiesPlus').on('click', function () {
    const v = parseInt($('#copies').val()) || 1;
    if (v < 99) $('#copies').val(v + 1);
  });
  $('#copiesMinus').on('click', function () {
    const v = parseInt($('#copies').val()) || 1;
    if (v > 1) $('#copies').val(v - 1);
  });

  // ── Calculate Price ─────────────────────────────────────────
  $('#calculateBtn').on('click', function () {
    clearFieldError('#fileError');
    clearFieldError('#copiesError');

    const file   = $('#fileInput')[0].files[0];
    const copies = parseInt($('#copies').val(), 10);
    let valid    = true;

    if (!file) {
      showFieldError('#fileError', '⚠ Please upload a PDF or DOC file.');
      valid = false;
    }
    if (!copies || copies < 1) {
      showFieldError('#copiesError', '⚠ Enter at least 1 copy.');
      valid = false;
    }
    if (!valid) return;

    // Show spinner on button
    setBtnLoading('#calculateBtn', true);

    const formData = new FormData();
    formData.append('file',      file);
    formData.append('printType', $('input[name="printType"]:checked').val());
    formData.append('copies',    copies);

    $.ajax({
      url:         'process.php',
      type:        'POST',
      data:        formData,
      processData: false,
      contentType: false,
      success: function (response) {
        setBtnLoading('#calculateBtn', false);
        const res = typeof response === 'string' ? JSON.parse(response) : response;

        if (res.error) {
          showFieldError('#fileError', '⚠ ' + res.error);
          return;
        }

        priceData = res;

        // Populate summary
        $('#sumFile').text(file.name);
        $('#sumPages').text(res.pages + ' pages');
        $('#sumType').text(res.printType);
        $('#sumRate').text('₹' + res.pricePerPage + ' per page');
        $('#sumCopies').text(res.copies);
        animateCount('#sumTotal', 0, res.total, '₹');

        // Populate payment amount
        $('#payAmount').text('₹' + res.total);

        goToStep(2);
      },
      error: function () {
        setBtnLoading('#calculateBtn', false);
        showFieldError('#fileError', '⚠ Server error. Please try again.');
      }
    });
  });

  // ── Back / Proceed ──────────────────────────────────────────
  $('#backToUpload').on('click', function () { goToStep(1); });
  $('#proceedToPayBtn').on('click', function () { goToStep(3); });

  // ── Copy UPI ID ─────────────────────────────────────────────
  $('#copyUpiBtn').on('click', function () {
    const upi = $('#upiIdText').text();
    navigator.clipboard.writeText(upi).then(function () {
      $('#copyUpiBtn').addClass('copied').find('span').text('Copied!');
      setTimeout(function () {
        $('#copyUpiBtn').removeClass('copied').find('span').text('Copy');
      }, 2000);
    });
  });

  // ── I Have Paid ─────────────────────────────────────────────
  $('#paidBtn').on('click', function () {
    setBtnLoading('#paidBtn', true);

    $.ajax({
      url:  'process.php',
      type: 'POST',
      data: { action: 'confirm' },
      success: function (response) {
        setBtnLoading('#paidBtn', false);
        const res = typeof response === 'string' ? JSON.parse(response) : response;

        const pickup = new Date(res.serverTime);
        pickup.setMinutes(pickup.getMinutes() + 15);
        const timeStr = pickup.toLocaleTimeString('en-IN', {
          hour: '2-digit', minute: '2-digit', hour12: true
        });

        $('#pickupTime').text(timeStr);
        $('#confirmMessage').text(
          'Your order has been placed successfully. See you soon!'
        );

        goToStep(4);
        launchConfetti();
      },
      error: function () {
        setBtnLoading('#paidBtn', false);
        showFieldError('#fileError', '⚠ Confirmation failed. Please try again.');
      }
    });
  });

  // ── New Order ───────────────────────────────────────────────
  $('#newOrderBtn').on('click', function () {
    resetFileInput();
    $('#copies').val(1);
    $('.type-card').removeClass('active');
    $('.type-card').first().addClass('active');
    $('input[name="printType"]').first().prop('checked', true);
    priceData = {};
    goToStep(1);
  });

  // ── Helpers ─────────────────────────────────────────────────
  function showFieldError(selector, msg) {
    $(selector).text(msg);
  }
  function clearFieldError(selector) {
    $(selector).text('');
  }

  function setBtnLoading(selector, loading) {
    const $btn = $(selector);
    $btn.prop('disabled', loading);
    $btn.find('.btn-text').toggleClass('hidden', loading);
    $btn.find('.btn-loader').toggleClass('hidden', !loading);
  }

  // Animate number count-up
  function animateCount(selector, from, to, prefix) {
    $({ val: from }).animate({ val: to }, {
      duration: 600,
      easing: 'swing',
      step: function () {
        $(selector).text(prefix + Math.floor(this.val));
      },
      complete: function () {
        $(selector).text(prefix + to);
      }
    });
  }

  // ── Confetti ────────────────────────────────────────────────
  function launchConfetti() {
    const colors = ['#4f6ef7','#a855f7','#22c55e','#f59e0b','#ef4444','#06b6d4'];
    const container = $('#confetti-container');
    container.empty();

    for (let i = 0; i < 80; i++) {
      const color = colors[Math.floor(Math.random() * colors.length)];
      const left  = Math.random() * 100;
      const delay = Math.random() * 1.5;
      const dur   = 2 + Math.random() * 2;
      const size  = 6 + Math.random() * 8;
      const shape = Math.random() > 0.5 ? '50%' : '2px';

      $('<div class="confetti-piece">')
        .css({
          left:            left + 'vw',
          background:      color,
          width:           size + 'px',
          height:          size + 'px',
          borderRadius:    shape,
          animationDuration: dur + 's',
          animationDelay:  delay + 's'
        })
        .appendTo(container);
    }

    // Clean up after animation
    setTimeout(function () { container.empty(); }, 5000);
  }

});
