# 🖨️ Online Printing Service System

## 📌 Project Description

The **Online Printing Service System** is a web-based application that allows users to upload documents (PDF/DOC), calculate printing costs instantly, and receive a pickup time after payment.

This project is developed using **HTML, CSS, jQuery, and AJAX**, focusing on asynchronous communication without page reload.

---

## 🎯 Objectives

* To provide an easy way for users to request print services online
* To calculate printing cost automatically
* To demonstrate the use of **jQuery and AJAX**
* To simulate an online payment and order confirmation system

---

## ⚙️ Features

* 📂 Upload PDF/DOC files
* 🖨️ Select print type (Black & White / Color)
* 🔢 Enter number of copies
* 💰 Automatic price calculation
* ⚡ AJAX-based interaction (no page reload)
* 💳 UPI payment instruction (demo)
* ⏱️ Pickup time generation

---

## 🧪 Technologies Used

* HTML
* CSS
* jQuery
* AJAX
* PHP (Backend)

---

## 🔄 System Workflow

1. User uploads a document
2. Selects print options
3. Clicks "Calculate Price"
4. AJAX sends data to server
5. Server calculates and returns price
6. User makes payment via UPI
7. System generates pickup time
8. User collects printed document

---

## 💰 Pricing Logic

* Black & White: ₹2 per page
* Color: ₹5 per page
* Total Cost = Pages × Cost × Copies

---

## 📡 AJAX Usage

AJAX is used to:

* Send file and user inputs to the server
* Receive calculated price
* Confirm payment
* Update UI dynamically without refreshing

---

## 📂 Project Structure

```
/project-folder
│── index.html
│── style.css
│── script.js
│── upload.php
│── /uploads
```

---

## 🚀 How to Run

1. Install XAMPP / WAMP
2. Place project folder in `htdocs`
3. Start Apache server
4. Open browser and go to:
   http://localhost/project-folder

---

## ⚠️ Limitations

* Payment is simulated (no real transaction)
* Page count may be approximated
* No user authentication

---

## 🔮 Future Enhancements

* Real payment gateway integration
* User login system
* Order tracking
* Admin dashboard

---

## 🎓 Conclusion

This project demonstrates how **jQuery and AJAX** can be used to build an interactive web application that performs real-time operations like file upload, price calculation, and order confirmation without reloading the page.

---

